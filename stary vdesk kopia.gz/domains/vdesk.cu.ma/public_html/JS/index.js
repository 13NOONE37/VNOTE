function change()
{
     document.getElementById("focus1").focus();
    const login = document.getElementById("login");
    const signup = document.getElementById("signup");
    const forget = document.getElementById("forget");
    
    const button_login = document.getElementById("button_login");
    const button_signup = document.getElementById("button_signup");
    const button_forget = document.getElementById("button_forget");
    const forgot_password = document.getElementById("Forgot_password");
    
    button_login.addEventListener("click", () => {
        login.classList.remove("display");
        login.classList.add("not_display");
        signup.classList.remove("not_display");
        signup.classList.add("display");
        document.getElementById("focus2").focus();
    });
    button_signup.addEventListener("click", () => {
        signup.classList.remove("display");
        signup.classList.add("not_display");
        login.classList.remove("not_display");
        login.classList.add("display");
        document.getElementById("focus1").focus();
    });
    button_forget.addEventListener("click", () => {
        login.classList.remove("not_display");
        login.classList.add("display");
        signup.classList.remove("display");
        signup.classList.add("not_display");
        forget.classList.remove("display");
        forget.classList.add("not_display");
        document.getElementById("focus1").focus();
    });
     forgot_password.addEventListener("click", () => {
        login.classList.remove("display");
        login.classList.add("not_display");
        signup.classList.remove("display");
        signup.classList.add("not_display");
        forget.classList.remove("not_display");
        forget.classList.add("display");
         document.getElementById("focus3").focus();
    });
    
}
window.onload=change;