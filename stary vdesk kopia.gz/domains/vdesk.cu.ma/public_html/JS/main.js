var click = true;
function change(){
    window.scrollTo(0,1);
    const e1 = document.getElementById("button");
    const e2 = document.getElementById("bar");
    const e3 = document.getElementById("main");
            
            e1.addEventListener("click", ()=>{
                if(click==true){
                        e1.classList.toggle("rotate");
                        e2.classList.toggle('hide_bar');
                        setTimeout(function(){ 
                        e2.classList.toggle("close_bar");
                        e3.classList.toggle("resize_main");         
                            }, 500);
                        click=false;
                } else {
                        e2.classList.toggle("close_bar");
                    setTimeout(function(){e3.classList.toggle("resize_main"); 
                        e1.classList.toggle("rotate");
                        e2.classList.toggle('hide_bar');     }, 1);
                        
                    click=true;
                }
                   
                      
                            
            });
    
    const e4 = document.getElementById("user");
    const e5 = document.getElementById("user_bar");
    const e6 = document.getElementById("close");
    e4.addEventListener("click", ()=>{
        e5.classList.toggle("move_animation");
    });
    e6.addEventListener("click", ()=>{
        e5.classList.toggle("move_animation");
    });
    
}
window.onload=change;