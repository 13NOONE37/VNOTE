<?php
header('Location: ../HTML/index.html');
?>